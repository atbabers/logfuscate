# Required imports
from gql import gql, Client
from gql.transport.aiohttp import AIOHTTPTransport

# Set up the AIOHTTPTransport with your Panther API URL and API key
transport = AIOHTTPTransport(
  url="https://api.skinny-tench.runpanther.net/public/graphql",
  headers={"X-API-Key": "65QjaNWwYw6EZlDoOVU83awRKBar1jKc4Oo0aCwv"},
)

# Initialize the GraphQL client
client = Client(transport=transport, fetch_schema_from_transport=True)

# Define the GraphQL query for 'schemas'
list_schemas = gql(
  """
  query ListSchemas($input: SchemasInput!) {
    schemas(input: $input) {
      edges {
        node {
          name
          description
          spec
        }
      }
    }
  }
  """
)

# Execute the query with the desired variables
data = client.execute(
  list_schemas,
  variable_values= {
    "input": {}
  }
)

# Print the response (you can adjust this to format the output as you wish)
print(data)